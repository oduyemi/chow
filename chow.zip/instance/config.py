SECRET_KEY = "jhfsduil73982389q"
CURRENCY = "₦"
SQLALCHEMY_DATABASE_URI = "mysql+mysqlconnector://root@localhost/chowdb"